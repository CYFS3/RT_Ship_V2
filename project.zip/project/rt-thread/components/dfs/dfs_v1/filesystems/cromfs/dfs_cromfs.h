/*
 * Copyright (c) 2006-2020, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020/08/21     ShaoJinchun  firset version
 */

#ifndef  __DFS_CROMFS_H__
#define  __DFS_CROMFS_H__

int dfs_cromfs_init(void);

#endif  /*__DFS_CROMFS_H__*/
